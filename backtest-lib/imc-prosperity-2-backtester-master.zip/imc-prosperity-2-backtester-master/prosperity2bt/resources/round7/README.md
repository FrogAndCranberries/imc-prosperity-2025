# Round 7

This directory contains the prices data that was used during end-of-round. Round 6 day X represents the end-of-round data of round X.
